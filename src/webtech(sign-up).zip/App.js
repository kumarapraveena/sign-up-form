import logo from './logo.svg';
import Form from './Form';
import './App.css';

function App() {
  return (
    <div className="App" >
    <Form></Form>
    </div>
  );
}

export default App;
